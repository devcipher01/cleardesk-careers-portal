import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  CheckCircle2,
  Clock,
  FileSignature,
  Loader2,
  Lock,
  Wallet,
} from "lucide-react";
import { OrgShell, OrgShellLoading } from "@/components/workspace/OrgShell";
import { VideoEmbed } from "@/components/site/VideoEmbed";
import { PIPELINE_SESSION_KEY } from "@/lib/careersPipeline";
import { getWorkspaceDashboardState } from "@/lib/server/actions";

interface Search {
  applicationId?: string;
}

export const Route = createFileRoute("/workspace")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    applicationId: typeof search.applicationId === "string" ? search.applicationId : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Contractor Workspace — Worknesta" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: WorkspaceDesktopPage,
});

function WorkspaceDesktopPage() {
  const { applicationId: searchId } = Route.useSearch();
  const [applicationId, setApplicationId] = useState<string | undefined>(searchId);
  const [loading, setLoading] = useState(true);
  const [allowed, setAllowed] = useState(false);
  const [candidateName, setCandidateName] = useState("");
  const [roleTitle, setRoleTitle] = useState("");
  const [scorePercent, setScorePercent] = useState<number | null>(null);
  const [contractSubmitted, setContractSubmitted] = useState(false);
  const [ndaSigned, setNdaSigned] = useState(false);

  useEffect(() => {
    const id =
      searchId ||
      (typeof window !== "undefined" ? sessionStorage.getItem(PIPELINE_SESSION_KEY) : null) ||
      undefined;
    setApplicationId(id ?? undefined);
    if (!id) {
      setLoading(false);
      return;
    }
    void (async () => {
      try {
        const state = await getWorkspaceDashboardState({ data: { applicationId: id } });
        if (!state.allowed) {
          setAllowed(false);
          return;
        }
        setAllowed(true);
        setCandidateName(state.candidateName);
        setRoleTitle(state.roleTitle);
        setScorePercent(state.scorePercent);
        setContractSubmitted(state.contractSubmitted);
        setNdaSigned(state.ndaSigned);
      } catch {
        setAllowed(false);
      } finally {
        setLoading(false);
      }
    })();
  }, [searchId]);

  if (loading) {
    if (applicationId) {
      return <OrgShellLoading applicationId={applicationId} activeNav="dashboard" />;
    }
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0f1419]">
        <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
      </div>
    );
  }

  if (!applicationId || !allowed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0f1419] px-4">
        <div className="max-w-md text-center">
          <Lock className="mx-auto h-10 w-10 text-slate-500" />
          <h1 className="mt-4 text-xl font-medium text-white">Workspace access required</h1>
          <p className="mt-2 text-sm text-slate-400">
            Open the link from your qualification email, or complete the Skills Profile Review first.
          </p>
          <div className="mt-6 flex items-center justify-center gap-3">
            <Link
              to="/workspace/signin"
              className="inline-flex items-center gap-2 rounded-lg bg-lime px-5 py-2.5 text-sm font-medium text-ink"
            >
              Sign in to workspace
            </Link>
            <Link
              to="/careers/apply"
              className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-4 py-2 text-sm text-slate-200"
            >
              View careers <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const firstName = candidateName.split(" ")[0] ?? "there";
  const setupComplete = contractSubmitted;

  return (
    <OrgShell
      applicationId={applicationId}
      candidateName={candidateName}
      roleTitle={roleTitle}
      activeNav="dashboard"
    >
      <div className="mx-auto max-w-5xl space-y-6">
        <div>
          <p className="text-sm text-slate-400">Good to see you,</p>
          <h1 className="text-2xl font-semibold text-white md:text-3xl">Welcome back, {firstName}</h1>
          <p className="mt-1 text-sm text-slate-400">
            Your contractor workspace for <span className="text-slate-200">{roleTitle}</span>
          </p>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4 md:p-6">
          <p className="mb-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
            Step 1 — Watch before you begin
          </p>
          <VideoEmbed
            label="ONBOARDING — Welcome to your workspace"
            caption="A short welcome from our onboarding team — please watch before starting setup"
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard
            icon={CheckCircle2}
            label="Skills profile"
            value={scorePercent != null ? `${scorePercent}%` : "—"}
            tone="emerald"
          />
          <StatCard icon={Wallet} label="Offered rate" value="$24.50/hr" tone="sky" />
          <StatCard
            icon={Clock}
            label="Onboarding"
            value={setupComplete ? "Complete" : ndaSigned ? "In progress" : "Action needed"}
            tone={setupComplete ? "emerald" : "amber"}
          />
        </div>

        {!setupComplete && (
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-6 md:p-8">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-300">
                  Action required
                </p>
                <h2 className="mt-2 text-xl font-medium text-white">Complete workspace setup</h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-amber-100/80">
                  Review your contractor agreement, confirm payment terms ($24.50/hr USD, weekly
                  disbursement), and sign required documents before accessing the production tools
                  provided by our third-party platform partner.
                </p>
              </div>
              <Link
                to="/onboarding/workspace-setup"
                search={{ applicationId }}
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-lime px-6 py-3 text-sm font-semibold text-ink hover:opacity-90"
              >
                <FileSignature className="h-4 w-4" />
                Start setup
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        )}

        {setupComplete && (
          <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6">
            <h2 className="text-lg font-medium text-white">Setup complete</h2>
            <p className="mt-2 text-sm text-emerald-100/80">
              Your contract is on file. A team lead will email your secure platform credentials before
              your training cohort begins.
            </p>
          </div>
        )}

        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <h3 className="text-sm font-medium text-white">Production queue</h3>
            <p className="mt-2 text-sm text-slate-400">
              {setupComplete
                ? "No tasks assigned yet. You will be notified when your queue opens."
                : "Unlocks after workspace setup and contract verification."}
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <h3 className="text-sm font-medium text-white">Payroll</h3>
            <p className="mt-2 text-sm text-slate-400">
              Weekly payments via Wise or Payoneer after your first approved production week.
            </p>
          </div>
        </div>
      </div>
    </OrgShell>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof CheckCircle2;
  label: string;
  value: string;
  tone: "emerald" | "sky" | "amber";
}) {
  const tones = {
    emerald: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
    sky: "border-sky-500/20 bg-sky-500/10 text-sky-300",
    amber: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  };
  return (
    <div className={`rounded-2xl border p-4 ${tones[tone]}`}>
      <Icon className="h-5 w-5 opacity-80" />
      <p className="mt-3 text-xs uppercase tracking-wide opacity-70">{label}</p>
      <p className="mt-1 text-lg font-semibold text-white">{value}</p>
    </div>
  );
}
