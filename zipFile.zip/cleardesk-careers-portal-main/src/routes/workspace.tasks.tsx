import { createFileRoute, Link } from "@tanstack/react-router";
import { ClipboardList, Clock3, Headphones, Sparkles } from "lucide-react";
import { OrgShell } from "@/components/workspace/OrgShell";

interface Search {
  applicationId?: string;
}

const TRANSCRIPTION_MODULES = Array.from({ length: 3 }, (_, moduleIndex) => ({
  title: `Module ${moduleIndex + 1}`,
  description: `Batch of 10 transcription tasks for the current onboarding cycle.`,
  tasks: Array.from({ length: 10 }, (_, taskIndex) => ({
    id: `${moduleIndex + 1}-${taskIndex + 1}`,
    title: `Transcription task ${moduleIndex * 10 + taskIndex + 1}`,
    duration: "15–20 min",
    focus: "Audio review and clean transcript",
  })),
}));

export const Route = createFileRoute("/workspace/tasks")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    applicationId: typeof search.applicationId === "string" ? search.applicationId : undefined,
  }),
  component: TasksPage,
});

function TasksPage() {
  const { applicationId } = Route.useSearch();

  return (
    <OrgShell applicationId={applicationId ?? ""} candidateName="" roleTitle="" activeNav="tasks">
      <div className="mx-auto flex max-w-6xl flex-col gap-6">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.25em] text-slate-400">
                Available tasks
              </p>
              <h1 className="mt-2 text-2xl font-semibold text-white">Transcription modules</h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">
                These task batches are ready for review. They are currently seeded locally so the
                workspace can be tested without a database sync.
              </p>
            </div>
            <div className="rounded-full border border-lime/20 bg-lime/10 px-3 py-2 text-sm text-lime">
              Demo queue • No sync required
            </div>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {TRANSCRIPTION_MODULES.map((module) => (
            <section key={module.title} className="rounded-2xl border border-white/10 bg-[#09111a] p-5">
              <div className="flex items-center gap-2 text-lime">
                <ClipboardList className="h-4 w-4" />
                <h2 className="text-lg font-semibold text-white">{module.title}</h2>
              </div>
              <p className="mt-2 text-sm text-slate-400">{module.description}</p>
              <div className="mt-4 space-y-2">
                {module.tasks.map((task) => (
                  <div
                    key={task.id}
                    className="rounded-xl border border-white/10 bg-white/5 p-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium text-white">{task.title}</p>
                        <p className="mt-1 text-xs text-slate-400">{task.focus}</p>
                      </div>
                      <span className="rounded-full border border-white/10 bg-[#0f1722] px-2.5 py-1 text-[11px] uppercase tracking-wide text-slate-300">
                        {task.duration}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-400">
                <span className="inline-flex items-center gap-2">
                  <Headphones className="h-3.5 w-3.5 text-slate-300" />
                  Audio-based review
                </span>
                <span className="inline-flex items-center gap-2">
                  <Clock3 className="h-3.5 w-3.5 text-slate-300" />
                  10 items
                </span>
              </div>
            </section>
          ))}
        </div>

        <div className="rounded-2xl border border-lime/20 bg-lime/10 p-5 text-sm text-lime/90">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            <span className="font-medium">Next step</span>
          </div>
          <p className="mt-2 leading-6 text-lime/80">
            When the backend is ready, these modules can be replaced with live task assignments while
            keeping the same local preview experience.
          </p>
          <div className="mt-4">
            <Link
              to="/workspace"
              className="inline-flex items-center rounded-full border border-lime/30 px-3 py-2 text-sm font-medium text-lime hover:bg-lime/20"
            >
              Return to dashboard
            </Link>
          </div>
        </div>
      </div>
    </OrgShell>
  );
}
