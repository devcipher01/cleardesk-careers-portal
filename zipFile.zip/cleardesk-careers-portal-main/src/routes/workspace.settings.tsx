import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { BellRing, CheckCircle2, ChevronRight, ShieldCheck, Sparkles } from "lucide-react";
import { OrgShell } from "@/components/workspace/OrgShell";

interface Search {
  applicationId?: string;
}

export const Route = createFileRoute("/workspace/settings")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    applicationId: typeof search.applicationId === "string" ? search.applicationId : undefined,
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { applicationId } = Route.useSearch();
  const [notifications, setNotifications] = useState(true);
  const [quietHours, setQuietHours] = useState(false);
  const [timezone, setTimezone] = useState("UTC");

  return (
    <OrgShell applicationId={applicationId ?? ""} candidateName="" roleTitle="" activeNav="settings">
      <div className="mx-auto flex max-w-4xl flex-col gap-6">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.25em] text-slate-400">Workspace settings</p>
              <h1 className="mt-2 text-2xl font-semibold text-white">Preferences and delivery</h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">
                These settings are wired locally for now so the workspace shell is fully usable before
                the backend is connected.
              </p>
            </div>
            <div className="rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300">
              Local preview mode
            </div>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="rounded-2xl border border-white/10 bg-[#09111a] p-5">
            <div className="flex items-center gap-2">
              <BellRing className="h-4 w-4 text-lime" />
              <h2 className="text-lg font-semibold text-white">Notifications</h2>
            </div>
            <div className="mt-4 space-y-4">
              <label className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                <span>Enable email reminders</span>
                <input
                  type="checkbox"
                  checked={notifications}
                  onChange={(event) => setNotifications(event.target.checked)}
                  className="h-4 w-4 rounded border-white/20 bg-transparent"
                />
              </label>
              <label className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                <span>Quiet hours</span>
                <input
                  type="checkbox"
                  checked={quietHours}
                  onChange={(event) => setQuietHours(event.target.checked)}
                  className="h-4 w-4 rounded border-white/20 bg-transparent"
                />
              </label>
              <label className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                <span>Timezone</span>
                <select
                  value={timezone}
                  onChange={(event) => setTimezone(event.target.value)}
                  className="rounded-lg border border-white/10 bg-[#0f1722] px-3 py-2 text-sm text-white"
                >
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">America/New_York</option>
                  <option value="Europe/London">Europe/London</option>
                </select>
              </label>
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-5">
              <div className="flex items-start gap-2">
                <ShieldCheck className="mt-0.5 h-4 w-4 text-emerald-300" />
                <div>
                  <h2 className="text-lg font-semibold text-white">Security</h2>
                  <p className="mt-2 text-sm leading-6 text-emerald-100/80">
                    Access stays protected behind the application-based workspace link.
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-[#09111a] p-5">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-lime" />
                <h2 className="text-lg font-semibold text-white">Status</h2>
              </div>
              <div className="mt-4 flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm text-slate-300">
                <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                <span>Workspace shell is functional and ready for follow-up integration.</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-sm text-slate-400">
          <span>Changes are stored in this browser session only.</span>
          <Link
            to="/workspace"
            className="inline-flex items-center gap-2 rounded-full border border-white/10 px-3 py-2 text-white hover:bg-white/10"
          >
            Back to dashboard
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </OrgShell>
  );
}
