import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { OrgShell } from "@/components/workspace/OrgShell";
import { sendSupportMessage } from "@/lib/server/actions";

interface Search {
  applicationId?: string;
}

export const Route = createFileRoute("/workspace/support")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    applicationId: typeof search.applicationId === "string" ? search.applicationId : undefined,
  }),
  component: SupportPage,
});

function SupportPage() {
  const { applicationId } = Route.useSearch();
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!applicationId) return setError("Missing application id");
    if (!message.trim() || message.trim().length < 5) return setError("Please enter a message");
    setSubmitting(true);
    setError("");
    try {
      await sendSupportMessage({ data: { applicationId, message: message.trim() } });
      setSent(true);
    } catch (e: any) {
      setError(e?.message || "Failed to send message");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <OrgShell applicationId={applicationId ?? ""} candidateName="" roleTitle="" activeNav="help">
      <section className="container-page max-w-2xl py-10">
        <div className="rounded-2xl border border-ink/10 bg-card p-6">
          <h1 className="text-2xl font-semibold">Contact support</h1>
          <p className="mt-2 text-sm text-ink/60">Send a message to the talent team and we'll get back to you via email.</p>

          {sent ? (
            <div className="mt-6 rounded-lg bg-emerald-500/10 p-4 text-emerald-300">Message sent — we will reply by email.</div>
          ) : (
            <div className="mt-6">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full min-h-[140px] p-3 rounded-lg bg-[#071018] text-white"
                placeholder="Describe your issue or question"
              />
              {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
              <div className="mt-4 flex items-center justify-end gap-3">
                <Link to="/workspace" className="text-sm text-slate-400">Back</Link>
                <button
                  onClick={submit}
                  disabled={submitting}
                  className="rounded-full bg-lime px-4 py-2 text-sm font-medium text-ink"
                >
                  {submitting ? "Sending…" : "Send message"}
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </OrgShell>
  );
}
